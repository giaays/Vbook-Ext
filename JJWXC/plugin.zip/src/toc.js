function execute(url) {
    var bookID = '0';
    if(url.indexOf("book2") !== -1) {
        bookID = url.split(/[/ ]+/).pop();
    }
    if(url.indexOf("novelid=") !== -1) {
        if(url.slice(-1) === "/") url = url.slice(0, -1);
        bookID = url.split("novelid=")[1];
        if(url.indexOf("&chapterid=") !== -1){
            bookID = bookID.split("&chapterid=")[0];
        }
    }

    let token = "error";
    if (typeof JJWXC_TOKEN !== 'undefined' && JJWXC_TOKEN && JJWXC_TOKEN.length > 20) {
        token = JJWXC_TOKEN;
    }

    let url1 = "https://app-cdn.jjwxc.net/androidapi/chapterList?novelId="+ bookID +"&more=0&whole=1";
    let response = fetch(url1);
    if (!response.ok) return null;
    
    let el = response.json().chapterlist;
    const data = [];
    for (let i = 0; i < el.length; i++) {
        if(el[i].chaptertype != '1') {
            let name = el[i].chapterid + ". " + el[i].chaptername.trim();
            let chapterid = el[i].chapterid;
            let link = 'https://app.jjwxc.net/androidapi/chapterContent?novelId='+bookID+'&chapterId='+chapterid;
            let buy = false;
            
            if(el[i].isvip > 0) {
                buy = true;
                link = "https://app.jjwxc.net/androidapi/chapterContent?novelId="+bookID+"&versionCode=349&chapterId="+chapterid+"&token="+token;
            }
            
            data.push({
                name: name,
                url: link,
                pay: buy,
                host: "https://app.jjwxc.net"
            });
        }
    }
    return Response.success(data);
}